@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add video</div>
				<div class="form-group row">
				<div class="col-sm-2">
				</div>
				<div class="col-sm-6">
					<form action="{{url('upload_video')}}" method="post" enctype="multipart/form-data">
					@csrf
					<div class="form-group">
					<label for="email">Video Name:</label>
					<input type="text" class="form-control" id="video_name" placeholder="Enter  Name" name="video_name" required>
					</div>
					<div class="form-group">
					<label for="email">Upload Video:</label>
					<input type="file" name="fileToUpload" class="form-control"  id="fileToUpload" accept="video/*" required>
					</div>
					<div class="form-group">
					<label for="email">Category :</label>
						<select class="form-control" id="sel1" name="video_cat" required>
						<option value=""> -- Select -- </option>
							@foreach($category as $data)
								<option value="{{$data->cat_id}}">{{$data->cat_name}}</option>
							@endforeach 
						</select>
					</div>
					
					
					<button type="submit" class="btn btn-default">Submit</button>
					</form>
				</div>
				<div class="col-sm-2">
				</div>
				</div>
            </div>
        </div>
    </div>
</div>
@endsection
