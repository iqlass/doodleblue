@extends('layouts.app')
<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.btn-like {background-color: #008CBA;} /* Blue */
.btn-Subscrib {background-color: #f44336;} /* Red */ 
</style>


@section('content')
<div class="container">
		@if(count($video)>0)
			<h3>{{$video[0]->cat_name}}</h3>
		@if(Session::has('msg'))
		@php 
			$msg = Session::get('msg');

		@endphp
			<div class="alert alert-info">
				<strong>{{$msg['status']}}!</strong>{{$msg['msg']}}.
			</div>

		@endif
		{{Session::forget('msg')}}
    
		<div class="row">
		
		@foreach($video as $videos)
		
			<div class="col-md-4">
				<div class="card">
					<div class="card-header text-center"><b>{{$videos->video_name}}
					@if($videos->subscription_type == 1)
							<b>( Free )</b>
							@else
							<b>( Subscription )</b>
							@endif
					</b></div>

					<div class="card-body">
					
						<video width="300" height="200" controls>
						<source src="../videos/{{$videos->video_id}}.{{$videos->video_ext}}" type="video/{{$videos->video_ext}}">
						
						</video>
					
						
							<a href="{{url('like_video')}}/{{$videos->video_cat}}"><input type="button" class="button btn-like " id="like_button" name="like" value="Like"></a>
							
							

					</div>
				</div>
			</div>
		@endforeach
		</div>
@else
	<h3 class=" text-center">NO Videos in this Category</h3>
@endif
    
</div>
@endsection
