@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit video</div>
				<div class="form-group row">
				<div class="col-sm-2">
				</div>
				<div class="col-sm-6">
					<form action="{{url('update_video')}}" method="post" enctype="multipart/form-data">
					@csrf
					<input type="hidden" name="id" value="{{$video[0]->video_id }}">
					<div class="form-group">
					<label for="email">Video Name:</label>
					<input type="text" class="form-control" id="video_name" placeholder="Enter  Name" name="video_name" value="{{$video[0]->video_name }}" required>
					</div>
					<div class="form-group">
					<label for="email">Upload Video:</label>
					<input type="file" name="fileToUpload" class="form-control"  id="fileToUpload" accept="video/*" >
						<br>
						<video width="150" height="75" controls>
							<source src="../videos/{{$video[0]->video_id}}.{{$video[0]->video_ext}}" type="video/{{$video[0]->video_ext}}">

						</video>
					</div>
					<div class="form-group">
					<label for="email">Category :</label>
						<select class="form-control" id="sel1" name="video_cat" required>
						<option value="{{$video[0]->cat_id}}"> {{$video[0]->cat_name}} </option>
							@foreach($category as $data)
								<option value="{{$data->cat_id}}">{{$data->cat_name}}</option>
							@endforeach 
						</select>
					</div>
					
					
					<button type="submit" class="btn btn-default">Submit</button>
					</form>
				</div>
				<div class="col-sm-2">
				</div>
				</div>
            </div>
        </div>
    </div>
</div>
@endsection
