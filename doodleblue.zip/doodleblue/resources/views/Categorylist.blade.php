@extends('layouts.app')

@section('content')
@if(Session::has('msg'))
	@php 
		$msg = Session::get('msg');

	@endphp
	<div class="alert alert-info">
  <strong>{{$msg['status']}}!</strong>{{$msg['msg']}}.
</div>

@endif
{{Session::forget('msg')}}
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Category List</div>
						<a href="{{url('add_category')}}"><button type="button" class="btn btn-success">
						 ADD NEW
						</button></a>
				<table class="table table-hover">
					<thead>
						<tr>
						<th>Category</th>
						<th>Action</th>
						</tr>
					</thead>
					<tbody>
					
					 @foreach($category as $data)
						<tr>
						<td>{{$data->cat_name}}</td>
						<td>
							<a href="{{url('edit_cat')}}/{{$data->cat_id }}"><button type="button" class="btn btn-info">
							 Eidt
							</button></a>
							<a href="{{url('delete_cat')}}/{{$data->cat_id }}"><button type="button" class="btn btn-danger">
							 Delete
							</button></a>
						</td>
						</tr>
						@endforeach 
					
					</tbody>
				</table>
            </div>
        </div>
    </div>
</div>
@endsection
