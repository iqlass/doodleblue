@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Edit Category</div>
				<div class="form-group row">
				<div class="col-sm-2">
				</div>
				<div class="col-sm-6">
					<form action="{{url('update_cate')}}" method="post">
					@csrf
					<input type="hidden" name="id" value="{{$category[0]->cat_id }}">
					<div class="form-group">
					<label for="email">Category:</label>
					<input type="text" class="form-control" id="category" placeholder="Enter Category Name" name="category" value="{{$category[0]->cat_name }}" required>
					</div>
					<div class="form-group">
					<label for="pwd">Subscription Type:</label>
						<label class="radio-inline"><input type="radio" id="subscription_type"  value="1" @if($category[0]->subscription_type == 1) checked  @endif name="subscription" required>Free</label>
						<label class="radio-inline"><input type="radio" id="subscription_type"  value="0"  @if($category[0]->subscription_type == 0) checked  @endif name="subscription" required>Subscription</label>
					</div>
					<div class="form-group" id="subscription_rate">
					<label for="email">RS:</label>
					<input type="number" class="form-control" id="rate" placeholder="Enter Price" name="price" @if($category[0]->price !=0) value="{{$category[0]->price}}" @endif>
					</div>
					<div class="form-group">
					<label for="email">Expiry Date:</label>
					<input type="date" class="form-control" id="expiry_date" placeholder="Enter Expiry Date" name="expiry_date" required value="{{$category[0]->expiry_date}}">
					</div>
					
					<button type="submit" class="btn btn-default">Submit</button>
					</form>
				</div>
				<div class="col-sm-2">
				</div>
				</div>
            </div>
        </div>
    </div>
</div>

@endsection



