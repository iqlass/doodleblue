@extends('layouts.app')

@section('content')
@if(Session::has('msg'))
	@php 
		$msg = Session::get('msg');

	@endphp
	<div class="alert alert-info">
  <strong>{{$msg['status']}}!</strong>{{$msg['msg']}}.
</div>

@endif
{{Session::forget('msg')}}
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Category List</div>
						
				<table class="table table-hover">
					<thead>
						<tr>
						<th>View Name</th>
						<th>Watching Time</th>
						</tr>
					</thead>
					<tbody>
					
					 @foreach($view_history as $data)
						<tr>
						<td>{{$data->view_history->video_name}}</td>
						<td>
							{{$data->created_at}}
						</td>
						</tr>
						@endforeach  
					
					</tbody>
				</table>
            </div>
        </div>
    </div>
</div>
@endsection
