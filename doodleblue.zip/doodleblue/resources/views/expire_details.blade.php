@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
					<table class="table table-bordered display"  style="width:100%">
						<thead>
						  <tr>
							<th>Category Name</th>
							<th>Expire Date</th>
							<th>Sent Mail </th>
							
	
						  </tr>
						</thead>
						<tbody>
						@if(isset($data))
							@foreach($data as $value)
							  <tr>
								<td>{{$value->cat_name}}</td>
								<td>{{$value->expiry_date }}</td>
								<td> <a href="{{url('sendmail')}}/{{$value->cat_id}}"><input type="button" class="btn btn-info" name="mail" value="Sent mail Alert"></a></td>
							
							  </tr>
						  @endforeach
						@endif  
						</tbody>
					  </table>
                   
					
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

