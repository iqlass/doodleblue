@extends('layouts.app')
<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.btn-like {background-color: #008CBA;} /* Blue */
.btn-Subscrib {background-color: #f44336;} /* Red */ 
</style>


@section('content')
<div class="container">
			
		@if(Session::has('msg'))
		@php 
			$msg = Session::get('msg');

		@endphp
			<div class="alert alert-info">
				<strong>{{$msg['status']}}!</strong>{{$msg['msg']}}.
			</div>

		@endif
		{{Session::forget('msg')}}
	<div class="card">
		<div class="card-header text-left">
		{{$video[0]->video_name}}
		<div>
		<div class="card-body">
			<video width="1000" height="500" controls>
				<source src="../videos/{{$video[0]->video_id}}.{{$video[0]->video_ext}}" type="video/{{$video[0]->video_ext}}">

			</video>
			<p>Total Like
			@if(isset($likes)  && array_key_exists($video[0]->video_id,$likes))
			{{$likes[$video[0]->video_id]}}
			@else
				0
			@endif
			</p>
			<br>
			<hr>
			<br>
					<div class="row">
					
					
		@foreach($data as $videos)
			<div class="col-md-4">
				<div class="card">
					<div class="card-header text-center"><b>{{$videos->video_name}}
					
					</b></div>

					<div class="card-body">
					
						<video width="300" height="200" >
						<source src="../videos/{{$videos->video_id}}.{{$videos->video_ext}}" type="video/{{$videos->video_ext}}">
						
						</video>
						<a href="{{url('view_videos')}}/{{$videos->video_id}}"><p class="text-center">View</p></a>
					
						
							<a href="{{url('like_video')}}/{{$videos->video_id}}"><input type="button" class="button btn-like" id="like_button" name="like" value="Like"></a>
								{{--  <a href="{{url('subscrib_video')}}/{{$videos->video_cat}}"><input type="button" class="button btn-Subscrib" id="like_button" name="like" value="Subscrib"></a> --}} 
							

					</div>
				</div>
			</div>
		@endforeach
		</div>
			
		<div>
	<div>
    
</div>
@endsection
