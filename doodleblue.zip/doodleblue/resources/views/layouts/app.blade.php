<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="{{ asset('js/formval.js') }}" defer></script>


    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="{{ asset('css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('css/jquery.dataTables.min.css') }}" rel="stylesheet">
    <link href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css" rel="stylesheet">
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                    {{ config('app.name') }}
                </a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
						 @if (isset( Auth::user()->user_type) && Auth::user()->user_type ==1)
							<li class="nav-item">
								<a class="nav-link" href="{{ url('Category_list') }}">{{ __('Category List ') }}</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="{{ url('Video_list') }}">{{ __('Videos ') }}</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="{{ url('view_user') }}">{{ __('Subscription Users List ') }}</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="{{ url('expire_details') }}">{{ __('Expire  Details ') }}</a>
							</li>
							<div class="navbar-nav dropdown" style="margin-top: 2%;">
							<a class="dropdown-toggle"  data-toggle="dropdown">Category
							<span class="caret"></span></a>
							<ul class="dropdown-menu">
							@if(isset($menu))
								@foreach($menu as $nav)
									<li style="margin-left: 7%;"><a href="{{url('view_category_view')}}/{{$nav->cat_id}}">{{$nav->cat_name}}</a></li>
								@endforeach
							@endif
							</ul>
						</div>
						@endif
						<li class="nav-item">
								<a class="nav-link" href="{{ url('view_playlist') }}">{{ __('Play List ') }}</a>
							</li>
							
							<li class="nav-item">
								<a class="nav-link" href="{{ url('view_history') }}">{{ __('View History ') }}</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="{{ url('my_liked_video') }}">{{ __('My Liked Video List ') }}</a>
							</li>
							
						

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                        <!-- Authentication Links -->
                        @guest
                            <li class="nav-item">
                                <a class="nav-link" href="{{ route('login') }}">{{ __('Login') }}</a>
                            </li>
                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}">{{ __('Register') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                        @csrf
                                    </form>
                                </div>
                            </li>
                        @endguest
                    </ul>
                </div>
            </div>
        </nav>
		
        <main class="py-4">
            @yield('content')
        </main>
    </div>
	    <script src="https://code.jquery.com/jquery-3.5.1.js" ></script>
    <script src="{{ asset('js/jquery.dataTables.min.js') }}" defer></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js" defer></script>
    <script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js" defer></script>
	<script>
	 $(document).ready(function() {
 $('#example').DataTable({
            "processing": true,
            "serverSide": true,
			dom: 'Bfrtip',
			buttons: [
				{
					text: '<i class="fas fa-file-pdf"></i> PDF',
					extend: 'pdf',
					text: 'Download',
					className: 'btn btn-danger',
					orientation: 'landscape',
					title: 'subscription user list ',

				}
			],
            "ajax": "{{ url('get_user_list') }}",
            "columns":[
                { "data": "name" },
                { "data": "email" },
                { "data": "cat_name" },
                { "data": "expiry_date" },
				
            ]
        });
		
         });
	</script>
</body>
</html>
