@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
					<table class="table table-bordered display"  id="example"  style="width:100%">
						<thead>
						  <tr>
							<th>Name</th>
							<th>Email</th>
							<th>Subscribe  Category </th>
							<th>Expire Date </th>
	
						  </tr>
						</thead>
						<tbody>
						{{--@if(isset($users))
							@foreach($users as $user)
							  <tr>
								<td>{{$user->name}}</td>
								<td>{{$user->email }}</td>
								<td>
								@if($user->user_type == 1)
									<b>Admin</b>
								@else
									<b>User</b>
								@endif
								</td>
								<td>{{$user->cat_name}}</td>
								<td>{{$user->expiry_date}}</td>
							  </tr>
						  @endforeach
						@endif  --}}
						</tbody>
					  </table>
                   
					
                </div>
            </div>
        </div>
    </div>
</div>

@endsection

