@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add Category</div>
				<div class="form-group row">
				<div class="col-sm-2">
				</div>
				<div class="col-sm-6">
					<form action="{{url('add_cate')}}" method="post">
					@csrf
					<div class="form-group">
					<label for="email">Category:</label>
					<input type="text" class="form-control" id="category" placeholder="Enter Category Name" name="category" required>
					</div>
					<div class="form-group">
					<label for="pwd">Subscription Type:</label>
						<label class="radio-inline"><input type="radio" id="subscription_type"  value="1" name="subscription" required>Free</label>
						<label class="radio-inline"><input type="radio" id="subscription_type"  value="0"  name="subscription" required>Subscription</label>
					</div>
					<div class="form-group" id="subscription_rate">
					<label for="email">RS:</label>
					<input type="number" class="form-control" id="rate" placeholder="Enter Price" name="price" >
					</div>
					<div class="form-group">
					<label for="email">Expiry Date:</label>
					<input type="date" class="form-control" id="expiry_date" placeholder="Enter Expiry Date" name="expiry_date" required>
					</div>
					
					<button type="submit" class="btn btn-default">Submit</button>
					</form>
				</div>
				<div class="col-sm-2">
				</div>
				</div>
            </div>
        </div>
    </div>
</div>
@endsection
