<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.btn-like {background-color: #008CBA;} /* Blue */
.btn-Subscrib {background-color: #f44336;} /* Red */ 
</style>


<?php $__env->startSection('content'); ?>
<div class="container">
			
		<?php if(Session::has('msg')): ?>
		<?php 
			$msg = Session::get('msg');

		?>
			<div class="alert alert-info">
				<strong><?php echo e($msg['status']); ?>!</strong><?php echo e($msg['msg']); ?>.
			</div>

		<?php endif; ?>
		<?php echo e(Session::forget('msg')); ?>

	<div class="card">
		<div class="card-header text-left">
		<?php echo e($video[0]->video_name); ?>

		<div>
		<div class="card-body">
			<video width="1000" height="500" controls>
				<source src="../videos/<?php echo e($video[0]->video_id); ?>.<?php echo e($video[0]->video_ext); ?>" type="video/<?php echo e($video[0]->video_ext); ?>">

			</video>
			<p>Total Like
			<?php if(isset($likes)  && array_key_exists($video[0]->video_id,$likes)): ?>
			<?php echo e($likes[$video[0]->video_id]); ?>

			<?php else: ?>
				0
			<?php endif; ?>
			</p>
			<br>
			<hr>
			<br>
					<div class="row">
					
					
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="card">
					<div class="card-header text-center"><b><?php echo e($videos->video_name); ?>

					
					</b></div>

					<div class="card-body">
					
						<video width="300" height="200" >
						<source src="../videos/<?php echo e($videos->video_id); ?>.<?php echo e($videos->video_ext); ?>" type="video/<?php echo e($videos->video_ext); ?>">
						
						</video>
						<a href="<?php echo e(url('view_videos')); ?>/<?php echo e($videos->video_id); ?>"><p class="text-center">View</p></a>
					
						
							<a href="<?php echo e(url('like_video')); ?>/<?php echo e($videos->video_id); ?>"><input type="button" class="button btn-like" id="like_button" name="like" value="Like"></a>
								 
							

					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
			
		<div>
	<div>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doodleblue\resources\views/view_video.blade.php ENDPATH**/ ?>