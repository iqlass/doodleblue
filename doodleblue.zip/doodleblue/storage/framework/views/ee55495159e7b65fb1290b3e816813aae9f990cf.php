<?php $__env->startSection('content'); ?>
<?php if(Session::has('msg')): ?>
	<?php 
		$msg = Session::get('msg');

	?>
	<div class="alert alert-info">
  <strong><?php echo e($msg['status']); ?>!</strong><?php echo e($msg['msg']); ?>.
</div>

<?php endif; ?>
<?php echo e(Session::forget('msg')); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Category List</div>
						<a href="<?php echo e(url('add_category')); ?>"><button type="button" class="btn btn-success">
						 ADD NEW
						</button></a>
				<table class="table table-hover">
					<thead>
						<tr>
						<th>Category</th>
						<th>Action</th>
						</tr>
					</thead>
					<tbody>
					
					 <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
						<td><?php echo e($data->cat_name); ?></td>
						<td>
							<a href="<?php echo e(url('edit_cat')); ?>/<?php echo e($data->cat_id); ?>"><button type="button" class="btn btn-info">
							 Eidt
							</button></a>
							<a href="<?php echo e(url('delete_cat')); ?>/<?php echo e($data->cat_id); ?>"><button type="button" class="btn btn-danger">
							 Delete
							</button></a>
						</td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
					
					</tbody>
				</table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doodleblue\resources\views/Categorylist.blade.php ENDPATH**/ ?>