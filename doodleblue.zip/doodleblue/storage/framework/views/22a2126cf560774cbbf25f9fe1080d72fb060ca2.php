<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
					<table class="table table-bordered display"  style="width:100%">
						<thead>
						  <tr>
							<th>Category Name</th>
							<th>Expire Date</th>
							<th>Sent Mail </th>
							
	
						  </tr>
						</thead>
						<tbody>
						<?php if(isset($data)): ?>
							<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							  <tr>
								<td><?php echo e($value->cat_name); ?></td>
								<td><?php echo e($value->expiry_date); ?></td>
								<td> <a href="<?php echo e(url('sendmail')); ?>/<?php echo e($value->cat_id); ?>"><input type="button" class="btn btn-info" name="mail" value="Sent mail Alert"></a></td>
							
							  </tr>
						  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>  
						</tbody>
					  </table>
                   
					
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doodleblue\resources\views/expire_details.blade.php ENDPATH**/ ?>