<style>
.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
.btn-like {background-color: #008CBA;} /* Blue */
.btn-Subscrib {background-color: #f44336;} /* Red */ 
</style>


<?php $__env->startSection('content'); ?>
<div class="container">
		<?php if(count($data)>0): ?>
			<h3><?php echo e($data[0]->cat_name); ?></h3>
		<?php if(Session::has('msg')): ?>
		<?php 
			$msg = Session::get('msg');

		?>
			<div class="alert alert-info">
				<strong><?php echo e($msg['status']); ?>!</strong><?php echo e($msg['msg']); ?>.
			</div>

		<?php endif; ?>
		<?php echo e(Session::forget('msg')); ?>

    
		<div class="row">
		<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-md-4">
				<div class="card">
					<div class="card-header text-center"><b><?php echo e($videos->video_name); ?>

					<?php if($videos->subscription_type == 1): ?>
							<b>( Free )</b>
							<?php else: ?>
							<b>( Subscription  RS : <?php echo e($videos->price); ?>)</b>
							<?php endif; ?>
					</b></div>

					<div class="card-body">
					
						<video width="300" height="200" >
						<source src="videos/<?php echo e($videos->video_id); ?>.<?php echo e($videos->video_ext); ?>" type="video/<?php echo e($videos->video_ext); ?>">
						
						</video>
						<?php if($subscription): ?>
							<?php for($i=0;$i<count($subscription);$i++): ?>
								<?php if($videos->video_cat ==$subscription[$i]->vid_cat_id ): ?>
									<a href="<?php echo e(url('view_videos')); ?>/<?php echo e($videos->video_id); ?>"><p class="text-center">View</p></a>
									<?php endif; ?>
								<?php endfor; ?>
						<?php endif; ?>
						
					
						
							<a href="<?php echo e(url('like_video')); ?>/<?php echo e($videos->video_id); ?>"><input type="button" class="button btn-like" id="like_button" name="like" value="Like"></a>
							<a href="<?php echo e(url('subscrib_video')); ?>/<?php echo e($videos->video_id); ?>"><input type="button" class="button btn-Subscrib" id="like_button" name="like" value="Subscrib"></a>
							

					</div>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
<?php else: ?>
	<h3 class=" text-center">NO Videos in this Category</h3>
<?php endif; ?>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doodleblue\resources\views/view_playlist.blade.php ENDPATH**/ ?>