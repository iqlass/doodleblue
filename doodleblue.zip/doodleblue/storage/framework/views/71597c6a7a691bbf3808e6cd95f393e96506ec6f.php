HI 
    Kindly Recharge Your Account
		Your Account Has Been Expired
<?php /**PATH C:\xampp\htdocs\doodleblue\resources\views/mail.blade.php ENDPATH**/ ?>