<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add video</div>
				<div class="form-group row">
				<div class="col-sm-2">
				</div>
				<div class="col-sm-6">
					<form action="<?php echo e(url('upload_video')); ?>" method="post" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="form-group">
					<label for="email">Video Name:</label>
					<input type="text" class="form-control" id="video_name" placeholder="Enter  Name" name="video_name" required>
					</div>
					<div class="form-group">
					<label for="email">Upload Video:</label>
					<input type="file" name="fileToUpload" class="form-control"  id="fileToUpload" accept="video/*" required>
					</div>
					<div class="form-group">
					<label for="email">Category :</label>
						<select class="form-control" id="sel1" name="video_cat" required>
						<option value=""> -- Select -- </option>
							<?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($data->cat_id); ?>"><?php echo e($data->cat_name); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						</select>
					</div>
					
					
					<button type="submit" class="btn btn-default">Submit</button>
					</form>
				</div>
				<div class="col-sm-2">
				</div>
				</div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\doodleblue\resources\views/add_video.blade.php ENDPATH**/ ?>