<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('auth.login');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');


Route::get('/like_video/{id}', 'Videocontroller@like_video');
Route::get('/subscrib_video/{id}', 'Videocontroller@subscrib_video');
Route::get('/view_videos/{id}', 'Videocontroller@view_videos');
Route::get('/view_history', 'Videocontroller@view_history');
Route::get('/view_user', 'HomeController@view_user');
Route::get('/get_user_list', 'HomeController@get_user_list');
Route::get('/view_playlist', 'Videocontroller@view_playlist');
Route::get('/my_liked_video', 'Videocontroller@my_liked_video');
Route::get('/my_subscription', 'Videocontroller@my_subscription');

Route::middleware([cheacksubscription::class])->group(function () {
Route::get('/Category_list', 'Categorycontroller@index');
Route::get('/add_category', 'Categorycontroller@addnew');
Route::post('/add_cate', 'Categorycontroller@add_cate');
Route::get('/edit_cat/{id}', 'Categorycontroller@edit_cat');
Route::get('/delete_cat/{id}', 'Categorycontroller@delete_cat');
Route::post('/update_cate', 'Categorycontroller@update_cate');
Route::get('/Video_list', 'Videocontroller@index');
Route::get('/add_video', 'Videocontroller@add_video');
Route::post('/upload_video', 'Videocontroller@upload_video');
Route::get('/delete_video/{id}', 'Videocontroller@delete_video');
Route::get('/edit_video/{id}', 'Videocontroller@edit_video');
Route::post('/update_video', 'Videocontroller@update_video');
Route::get('/view_category_view/{id}','Categorycontroller@view_category_view');
Route::get('/sendmail/{id}', 'HomeController@sendmail');
Route::get('/expire_details', 'HomeController@expire_details');
});
