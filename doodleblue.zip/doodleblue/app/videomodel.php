<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Categorymodel;
class videomodel extends Model
{
	 protected $table = 'tbl_video';
	 protected $primaryKey = 'video_id';
     protected $fillable = [
        'video_name', 'video_ext', 'video_size','video_cat',
    ];

		public function Category(){
		return $this->hasMany(Categorymodel::class,'cat_id');
	}
}
