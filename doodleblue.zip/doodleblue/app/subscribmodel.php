<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Categorymodel;
use App\User;
class subscribmodel extends Model
{
     protected $table = 'tbl_subscrib';
	 protected $primaryKey = 'sb_id';
     protected $fillable = [
        'vid_cat_id', 'user_id', 
    ];
	public function subscription_cat(){
		return $this->hasMany(Categorymodel::class,'cat_id');
	}
	public function subscription_user(){
		return $this->hasMany(User::class,'id');
	}
	public function my_subscription(){
		return $this->belongsTo(Categorymodel::class,'cat_id');
	}
}
