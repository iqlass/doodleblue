<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\videomodel;

class tbl_viewhistroy extends Model
{
    protected $table = 'tbl_viewhistory';
	 protected $primaryKey = 'view_id';
     protected $fillable = [
        'video_id', 'user_id'
    ];
	public function view_history(){
		return $this->belongsTo(videomodel::class,'video_id');
	}
}
