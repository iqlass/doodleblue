<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class mailcontroller extends Controller
{
    //
}
