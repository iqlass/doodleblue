<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Session;
use Exception;
use App\Categorymodel;
use redirect;
use DB;

class Categorycontroller extends Controller
{
        public function __construct()
    {
        $this->middleware('auth');
    }
	    public function index()
    {
		$category = Categorymodel::all();
		
        return view('Categorylist')->with('category',$category);
    }
	public function addnew(){
		 return view('addCategory');
	}
	public function add_cate(request $request){
		try{
			$check_category = $this->check_category($request['category']);
			if($check_category >0){
				$data = array('status'=>'success','msg'=>'This Record Already  Inserted');
			}else{
				$price = 0;
				if($request['subscription'] == 0){
					$price = $request['price'];
				}
				Categorymodel::Create([
				'cat_name' =>$request['category'],
				'subscription_type' =>$request['subscription'],
				'price' =>$price,
				'expiry_date' =>$request['expiry_date'],
				]);
				$data = array('status'=>'success','msg'=>'Insert successfully');
			}
		}
		catch(Exception $e){
		$data = array('status'=>'error','msg'=>$e->getMessage());
		}
		finally{
			Session::put('msg',$data);
			return redirect('Category_list');
		}
	}
	public function edit_cat($id){
		$res=Categorymodel::where('cat_id',$id)->get();
		return view('edit_cate')->with('category',$res);
	}
	public function delete_cat($id){
		$res=Categorymodel::where('cat_id',$id)->delete();
		$data = array('status'=>'success','msg'=>'Deleted successfully');
		Session::put('msg',$data);
		return redirect('Category_list');
	}
	public function update_cate(request $request){
		try{
			$price = 0;
			if($request['subscription'] == 0){
				$price = $request['price'];
			}
			$UpdateDetails = Categorymodel::find($request['id']);
			$UpdateDetails->cat_name = $request['category'];
			$UpdateDetails->subscription_type = $request['subscription'];
			$UpdateDetails->price = $price;
			$UpdateDetails->expiry_date = $request['expiry_date'];
			$UpdateDetails->save();
			
			$data = array('status'=>'success','msg'=>'Insert successfully');
		}
		catch(Exception $e){
		$data = array('status'=>'error','msg'=>$e->getMessage());
		}
		finally{
			Session::put('msg',$data);
			return redirect('Category_list');
		}
	}
	public function check_category($cat){
		$cat_count = Categorymodel::where('cat_name',$cat)->count();
		
		return $cat_count;
	}
	public function view_category_view($id){
		$video1 = Categorymodel::with('video')->get();
	
		
		
		
		$video = DB::table('tbl_catrgory')
		->where('tbl_catrgory.cat_id',$id)
		->join('tbl_video', 'tbl_video.video_cat', '=', 'tbl_catrgory.cat_id')
		->get(); 
		return view('view_category_list')->with('video',$video);
	}
}
