<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;
use App\videomodel;
use App\Categorymodel;
use App\videolike;
use App\vodeicatlist;
use App\subscribmodel;
use App\tbl_viewhistroy;
use Session;

class Videocontroller extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }
	public function index(){

		$video = DB::table('tbl_video')
		->join('tbl_catrgory', 'tbl_catrgory.cat_id', '=', 'tbl_video.video_cat')
		->get(); 
		
		return view('video_list')->with('video',$video);
	}
	public function add_video(){
		$category = DB::table('tbl_catrgory')->get();
		return view('add_video')->with('category',$category);
	}
	public function  upload_video(request $request){
		try{
			if($request->file('fileToUpload')){
				$maxsize    = 2097152;
				$file = $request->file('fileToUpload');
				$file_ext = $file->getClientOriginalExtension();
				$file_name =  $file->getClientOriginalName();
				$file_path = $file->getRealPath();
				$file_size = $file->getSize();
				$upload_path = public_path('videos'); 
				if($file_size > $maxsize ){
					$data = array('status'=>'Error','msg'=>'Video Max Size 2MB and Olny Formate MP4');
				}else{
					$sql =  DB::table('tbl_video')->insertGetId(
							array('video_name' => $request['video_name'],
								'video_ext' => $file_ext,
								'video_size' => $file_size,
								'video_cat' => $request['video_cat'],
								)
							); 
					$custom_file_name = $sql.'.'.$file_ext;
					$path = $file->move($upload_path,$custom_file_name);
					$data = array('status'=>'success','msg'=>'Insert Successfully');
				}
				
			}
		}
		catch(Exception $e){
		$data = array('status'=>'error','msg'=>$e->getMessage());
		}
		finally{
			Session::put('msg',$data);
			return redirect('Video_list');
		}
	}
	public function delete_video($id){
		$res=videomodel::where('video_id',$id)->delete();
		$data = array('status'=>'success','msg'=>'Deleted successfully');
		Session::put('msg',$data);
		return redirect('Video_list');
	}
	public function edit_video($id){
		$video = DB::table('tbl_video')
		->where('tbl_video.video_id',$id)
		->join('tbl_catrgory', 'tbl_catrgory.cat_id', '=', 'tbl_video.video_cat')->get();
		$category = DB::table('tbl_catrgory')->get();
		return view('edit_video',compact('video','category'));
		
	}
	public function update_video(request $request){
		
			try{
				
				if($request->file('fileToUpload')){
					$maxsize    = 2097152;
					$file = $request->file('fileToUpload');
					$file_ext = $file->getClientOriginalExtension();
					$file_name =  $file->getClientOriginalName();
					$file_path = $file->getRealPath();
					$file_size = $file->getSize();
					 
					if($file_size > $maxsize ){
						$data = array('status'=>'Error','msg'=>'Video Max Size 2MB and Olny Formate MP4');
						
					}else{
						$upload_path = public_path('videos');
						File::delete($upload_path.$request['id'].$file_ext);
						$UpdateDetails = videomodel::find($request['id']);
						$UpdateDetails->video_name = $request['video_name'];
						$UpdateDetails->video_ext = $file_ext;
						$UpdateDetails->video_size = $file_size;
						$UpdateDetails->video_cat = $request['video_cat'];
						$UpdateDetails->save();
						$custom_file_name = $request['id'].'.'.$file_ext;
						$path = $file->move($upload_path,$custom_file_name);
						$data = array('status'=>'success','msg'=>'File Updated Successfully');
					
					}
					
				}else{
					
						$UpdateDetails = videomodel::find($request['id']);
						$UpdateDetails->video_name = $request['video_name'];
						$UpdateDetails->video_cat = $request['video_cat'];
						$UpdateDetails->save();
						
						$data = array('status'=>'success','msg'=>'File Updated Successfully');
						
				}
		}
		catch(Exception $e){
		$data = array('status'=>'error','msg'=>$e->getMessage());
		}
		finally{
			Session::put('msg',$data);
			
			return redirect('Video_list');
		}
	}
	public function like_video($id){
		$check_like_video = $this->check_like_video($id);
		if($check_like_video == 0){
			$User_id = Auth::user()->id;
			videolike::Create([
				'video_id' =>$id,
				'user_id' =>$User_id,
			]);
			$data = array('status'=>'success','msg'=>'Thank You For Like This Video');
			Session::put('msg',$data);
			return redirect(url()->previous());
		}else{
				$data = array('status'=>'success','msg'=>'This Video Already Liked');
			Session::put('msg',$data);
			return redirect(url()->previous());
		}
		
	}
	public function check_like_video($id){
		$User_id = Auth::user()->id;
		$count = videolike::where('video_id' , $id)
		->where('user_id', $User_id)
		->count();
		return $count;
	}
	public function unlikevideo($id){
		$User_id = Auth::user()->id;
		$res=videolike::where('video_id',$id)
		->where('user_id', $User_id)
		->delete();
		$data = array('status'=>'success','msg'=>'Thank You For UnLike This Video');
			Session::put('msg',$data);
			return redirect(url()->previous());
		
	}
	public function view_playlist(){
		 $data = DB::table('tbl_catrgory')
            ->leftjoin('tbl_video', 'tbl_catrgory.cat_id', '=', 'tbl_video.video_cat')->get();
		$subscription = subscribmodel::where('user_id',Auth::user()->id)->get();
			//dd($subscription[1]->vid_cat_id);
		return view("view_playlist",compact('data','subscription'));
		 
	}
	public function subscrib_video($id){
	
		$check_Subscrip_video = $this->check_Subscrip_video($id);
		if($check_Subscrip_video == 0){
			$User_id = Auth::user()->id;
				subscribmodel::Create([
					'vid_cat_id' =>$id,
					'user_id' =>$User_id,
				]);
				$data = array('status'=>'success','msg'=>'Thank You For Subscrip This Video');
				Session::put('msg',$data);
				return redirect(url()->previous());
		}else{
			$data = array('status'=>'success','msg'=>'This Video already Subscrip');
				Session::put('msg',$data);
				return redirect(url()->previous());
		}
		
	}
	public function check_Subscrip_video($id){
		$User_id = Auth::user()->id;
		$count = subscribmodel::where('vid_cat_id' , $id)
		->where('user_id', $User_id)
		->count();
		return $count;
	}
	public function view_videos($id){
		$User_id = Auth::user()->id;
		tbl_viewhistroy::Create([
					'video_id' =>$id,
					'user_id' =>$User_id,
				]);
		$video = videomodel::where('video_id',$id)->get();
		$data = videomodel::where('video_cat',$video[0]->video_cat)->get();
		$like = videolike::select('video_id')->get();
		
		
		if(isset($like) && count($like) > 0 ){
		for($i=0;$i<count($like);$i++){
			$like_count[$i] = $like[$i]->video_id;
			
		}
		$likes = array_count_values($like_count);
		}else{
			$likes[0]  = 0;
		}
		
		return view("view_video",compact('video','data','likes'));
	}
	public function view_history(){
		$User_id = Auth::user()->id;
		$view_history = tbl_viewhistroy::with('view_history')->where('user_id',$User_id)->get();
		//dd($view_history);
		return view('view_history',compact('view_history'));
		
	}
	public function my_liked_video(){
		$User_id = Auth::user()->id;
		$video = videolike::with('liked_vide')->where('user_id',$User_id)->get();
		return view('like_history',compact('video'));
	}
	public function my_subscription(){
			$User_id = Auth::user()->id;
			$video = subscribmodel::where('my_subscription')->where('user_id',$User_id)->get();
	}
}
