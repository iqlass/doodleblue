<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\User;
use App\subscribmodel;
use App\Categorymodel;
use datatables;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMailable;
use Session;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
	public function view_user(){
		 //$users = User::all();
		
		 return view('user_list');
	}
	public function get_user_list(){
		$data = subscribmodel::with('subscription_cat','subscription_user')->get();
		
		return datatables()->of(DB::select("select * from tbl_subscrib as s,tbl_catrgory as c,users as u  where s.vid_cat_id = c.cat_id  and s.user_id = u.id"))->toJson();
	}
	public function sendmail($id)
{
	$users_list = subscribmodel::with('subscription_user')->get();
	
	foreach($users_list as $user){
		$name = $user->subscription_user[0]->name;
		$email = $user->subscription_user[0]->email;
		

      $data = array('name'=>$name,'email' =>$email);
	 
      Mail::send(['text'=>'mail'], $data, function($message) use($data) {
         $message->to($data['email'],$data['name'])->subject
            ('Kindly Recharge Your Account');
         $message->from('iqlass1994@gmail.com','mohamed iqlass');
      });
      
	}
	$data = array('status'=>'success','msg'=>'Email Senting Successfully');
				Session::put('msg',$data);
				return redirect(url()->previous());
}
public function expire_details(){
	$Today=date('Y-m-d');
	$NewDate=Date('Y-m-d', strtotime('+1 days'));
	$data =Categorymodel::where('expiry_date', '<=',$NewDate)->get();
	return view("expire_details",compact('data'));
}
}
