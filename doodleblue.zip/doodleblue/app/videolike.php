<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;

class videolike extends Model
{
     protected $table = 'tbl_videolike';
	 protected $primaryKey = 'lk_id';
     protected $fillable = [
        'video_id', 'user_id', 
    ];
	public function liked_vide(){
		return $this->belongsTo(videomodel::class,'video_id');
	}

}
