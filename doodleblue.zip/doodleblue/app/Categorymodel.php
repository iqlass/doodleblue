<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\videomodel;
use App\User;

class Categorymodel extends Model
{
	 protected $table = 'tbl_catrgory';
	 protected $primaryKey = 'cat_id';
     protected $fillable = [
        'cat_name', 'subscription_type', 'price','expiry_date',
    ];
	
	public function video(){
		return $this->hasMany(videomodel::class,'video_cat');
	}

}
