$("input[id='subscription_type']"). click(function(){

if($("input[id='subscription_type']:checked"). val() == 1){
	$("#subscription_rate").hide(1000);
	$("input[id='rate']"). prop("required", false);
}else{
	$("#subscription_rate").show(1000);
	$("input[id='rate']"). prop("required", true);
}
});


if($("input[id='subscription_type']:checked"). val() == 1){
	$("#subscription_rate").hide(1000);
	$("input[id='rate']"). prop("required", false);
}else if($("input[id='subscription_type']:checked"). val() == 0){
	$("#subscription_rate").show(1000);
	$("input[id='rate']"). prop("required", true);
}

$('input[id="fileToUpload"]').change(function(e){
	 var ext = this.value.match(/\.([^\.]+)$/)[1];
  switch (ext) {
    case 'mp4':
    case 'ogg':
      
      break;
    default:
      alert('MP4 Video Only Allowed');
      this.value = '';
  }
	 
 });
 
/* var file = document.getElementById('fileToUpload');
function fileupload(e){
	alert("DFGFD");
file.onchange = function(e) {
  var ext = this.value.match(/\.([^\.]+)$/)[1];
  switch (ext) {
    case 'jpg':
    case 'bmp':
    case 'png':
    case 'tif':
      alert('Allowed');
      break;
    default:
      alert('Not allowed');
      this.value = '';
  }
};
} */