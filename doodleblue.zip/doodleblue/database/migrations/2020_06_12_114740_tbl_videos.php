<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TblVideos extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
         Schema::create('tbl_video', function (Blueprint $table) {
            $table->bigIncrements('video_id');
            $table->string('video_name');
            $table->string('video_ext');
            $table->Integer('video_size');
            $table->tinyInteger('video_cat');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         Schema::dropIfExists('tbl_video');
    }
}
